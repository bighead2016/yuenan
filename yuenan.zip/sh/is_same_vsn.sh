cd ../ebin
erl -d -pa . -s misc_app is_same_vsn_stop -noshell
