#!/bin/sh
erl -d -pa ../ebin -name combine@127.0.0.1 -setcookie aaaaa -s combine_api main