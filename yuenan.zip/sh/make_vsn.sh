cd ../ebin
erl -d -pa . -s misc_app mark_vsn_stop -noshell
