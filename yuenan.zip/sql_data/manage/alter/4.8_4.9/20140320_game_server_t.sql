alter TABLE `game_server_t` add column `node` blob NOT NULL COMMENT '结点名' after `combine`;
