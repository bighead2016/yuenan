ALTER TABLE `game_player`     
ADD COLUMN `partner_soul` LONGBLOB NOT NULL COMMENT '����' AFTER `furnace`;