ALTER TABLE `game_archery_info`
ADD COLUMN `instruction` int(2) NOT NULL DEFAULT 0 COMMENT '新手引导次数';