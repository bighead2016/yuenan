ALTER TABLE `game_archery_info`
ADD COLUMN `limit_buy` int(3) NOT NULL DEFAULT 0 COMMENT '每日购买次数限制';