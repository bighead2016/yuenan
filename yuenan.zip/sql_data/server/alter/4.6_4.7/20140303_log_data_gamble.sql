CREATE TABLE `log_data_gamble`(
`user_id` int(11),
`user_sid` int(3),
`chip1` int(5),
`user_id2` int(11),
`user_sid1` int(3),
`chip2` int(5),
`time` int(11)
)DEFAULT CHARSET=utf8;