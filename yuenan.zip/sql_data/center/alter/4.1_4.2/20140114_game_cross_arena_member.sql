alter table game_cross_arena_member modify column partner_list varchar(200) NOT NULL DEFAULT '';
alter table game_cross_arena_member modify column fight_list varchar(200) NOT NULL DEFAULT '';