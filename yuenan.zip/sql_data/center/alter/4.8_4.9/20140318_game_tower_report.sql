truncate `game_tower_report`;
truncate `game_tower_report_idx`;
truncate `game_copy_single_report`;
truncate `game_copy_single_report_idx`;
